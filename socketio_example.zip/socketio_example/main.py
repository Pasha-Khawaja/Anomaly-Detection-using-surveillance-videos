# create flask app
from distutils.log import debug
from flask import Flask, render_template, request, redirect, url_for
from flask_socketio import SocketIO, emit
import time

app = Flask(__name__)
socketio = SocketIO(app)

# on connection
@socketio.on('connect')
def connect():
    print('connected')


@socketio.on("my event")
def test_message(message):
    for i in range(4):
        time.sleep(1)
        emit("my response", {"data": message['data'] + "-" + str(i)})

@app.route('/')
def main():
    return render_template("index.html")


if __name__ == '__main__':
    socketio.run(app, debug=True)